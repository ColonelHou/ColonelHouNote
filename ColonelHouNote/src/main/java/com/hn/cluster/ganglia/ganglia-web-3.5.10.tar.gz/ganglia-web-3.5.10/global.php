<?php
$SHOW_EVENTS_BASE_ID = "show_events_";
$TIME_SHIFT_BASE_ID = "time_shift_";
$GRAPH_BASE_ID = "graph_img_";
?>